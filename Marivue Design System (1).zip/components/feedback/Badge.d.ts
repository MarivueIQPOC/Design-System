/**
 * Badge — status pill (at berth, inbound, critical alert)
 * @usage
 * <Badge variant="success">At Berth</Badge>
 * <Badge variant="critical">Alert</Badge>
 */
export interface BadgeProps {
  /** Variant: success, warn, critical, info, muted */
  variant?: 'success' | 'warn' | 'critical' | 'info' | 'muted';
  /** Text content */
  children: React.ReactNode;
  /** className */
  className?: string;
}
