export function Badge({ variant = 'info', children, className = '' }) {
  const variantBg = {
    success: 'var(--success)',
    warn: 'var(--warn-bg)',
    critical: 'var(--critical-bg)',
    info: 'var(--info)',
    muted: 'var(--text-muted)',
  }[variant];

  return (
    <span
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '4px 10px',
        borderRadius: 'var(--radius-full)',
        background: variantBg,
        color: '#FFFFFF',
        fontSize: '11px',
        fontWeight: 600,
        fontFamily: 'var(--font-sans)',
        textTransform: 'uppercase',
        letterSpacing: '0.04em',
        whiteSpace: 'nowrap',
      }}
    >
      {children}
    </span>
  );
}
