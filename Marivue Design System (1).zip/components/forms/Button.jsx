export function Button({
  variant = 'primary',
  size = 'md',
  icon,
  iconPosition = 'before',
  disabled = false,
  block = false,
  onClick,
  children,
  className = '',
}) {
  const baseStyle = {
    display: block ? 'flex' : 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
    borderRadius: 'var(--radius-sm)',
    fontFamily: 'var(--font-sans)',
    fontWeight: 600,
    fontSize: '14px',
    cursor: disabled ? 'not-allowed' : 'pointer',
    border: 'none',
    transition: 'all 150ms ease',
    opacity: disabled ? 0.5 : 1,
    width: block ? '100%' : 'auto',
  };

  const sizeStyles = {
    sm: { padding: '6px 12px', minHeight: '28px' },
    md: { padding: '8px 16px', minHeight: '36px' },
    lg: { padding: '12px 20px', minHeight: '44px' },
  }[size];

  const variantStyles = {
    primary: {
      background: 'var(--accent)',
      color: '#FFFFFF',
      borderColor: 'var(--accent)',
    },
    secondary: {
      background: 'transparent',
      color: 'var(--text-2)',
      border: '1px solid var(--border-strong)',
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-2)',
      border: 'none',
    },
    critical: {
      background: 'var(--critical-bg)',
      color: '#FFFFFF',
      border: 'none',
    },
  }[variant];

  return (
    <button
      style={{ ...baseStyle, ...sizeStyles, ...variantStyles }}
      disabled={disabled}
      onClick={onClick}
      className={className}
    >
      {iconPosition === 'before' && icon && <span>{icon}</span>}
      {children}
      {iconPosition === 'after' && icon && <span>{icon}</span>}
    </button>
  );
}
