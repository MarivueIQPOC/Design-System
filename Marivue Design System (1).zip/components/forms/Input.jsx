export function Input({
  type = 'text',
  label,
  placeholder,
  value,
  onChange,
  disabled = false,
  error,
  icon,
  block = false,
  className = '',
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', width: block ? '100%' : 'auto' }}>
      {label && (
        <label style={{
          fontSize: '12px',
          fontWeight: 600,
          color: 'var(--text-muted)',
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
        }}>
          {label}
        </label>
      )}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
        {icon && (
          <span style={{ position: 'absolute', left: '12px', color: 'var(--text-muted)', fontSize: '16px' }}>
            {icon}
          </span>
        )}
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          disabled={disabled}
          className={className}
          style={{
            width: '100%',
            padding: icon ? '10px 12px 10px 40px' : '10px 12px',
            borderRadius: 'var(--radius-sm)',
            border: `1px solid ${error ? 'var(--critical-bg)' : 'var(--border)'}`,
            background: 'var(--surface)',
            color: 'var(--text)',
            fontFamily: 'var(--font-sans)',
            fontSize: '14px',
            transition: 'border 150ms ease',
            opacity: disabled ? 0.5 : 1,
            cursor: disabled ? 'not-allowed' : 'text',
          }}
          onFocus={(e) => e.target.style.borderColor = 'var(--accent)'}
          onBlur={(e) => e.target.style.borderColor = error ? 'var(--critical-bg)' : 'var(--border)'}
        />
      </div>
      {error && (
        <span style={{ fontSize: '12px', color: 'var(--critical-bg)', marginTop: '2px' }}>
          {error}
        </span>
      )}
    </div>
  );
}
