/**
 * Input field — text, number, search, with label and optional icon
 * @usage
 * <Input label="Vessel Name" placeholder="Search..." />
 * <Input type="number" label="Berth ID" />
 */
export interface InputProps {
  /** Input type */
  type?: 'text' | 'number' | 'email' | 'password' | 'search';
  /** Label text */
  label?: string;
  /** Placeholder text */
  placeholder?: string;
  /** Current value */
  value?: string;
  /** onChange handler */
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Disabled state */
  disabled?: boolean;
  /** Error state and message */
  error?: string;
  /** Optional icon/prefix */
  icon?: React.ReactNode;
  /** Full width */
  block?: boolean;
  /** className */
  className?: string;
}
