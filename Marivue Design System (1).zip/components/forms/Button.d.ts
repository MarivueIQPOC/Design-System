/**
 * @dsCard group="Components" viewport="700x320" name="Button"
 * @startingPoint section="Forms & Controls" subtitle="Primary, secondary, ghost, icon-only variants" viewport="280x120"
 */

/**
 * Button — primary, secondary, ghost, icon
 * @usage
 * <Button variant="primary" size="md" onClick={handler}>Action</Button>
 * <Button variant="secondary">Secondary</Button>
 * <Button variant="ghost" icon="AlertCircle" />
 */
export interface ButtonProps {
  /** Visual style: primary (accent), secondary (navy outline), ghost (text-only) */
  variant?: 'primary' | 'secondary' | 'ghost' | 'critical';
  /** Size: sm (28px), md (36px), lg (44px) */
  size?: 'sm' | 'md' | 'lg';
  /** Icon from Lucide (optional) */
  icon?: string;
  /** Icon position: before or after text */
  iconPosition?: 'before' | 'after';
  /** Disabled state */
  disabled?: boolean;
  /** Full width */
  block?: boolean;
  /** Click handler */
  onClick?: (e: React.MouseEvent) => void;
  /** Children (text label) */
  children?: React.ReactNode;
  /** className for additional styles */
  className?: string;
}

/**
 * @editor text
 * @default "Click me"
 */
export const buttonLabel = "Click me";

/**
 * @editor enum
 * @options ["primary", "secondary", "ghost"]
 * @default "primary"
 */
export const buttonVariant = "primary";
