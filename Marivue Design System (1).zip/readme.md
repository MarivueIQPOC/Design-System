# Marivue Design System

## Company Context

**Marivue** is an intelligence layer that connects to Terminal Operating Systems (TOS) — primarily Navis N4 — and helps port/terminal operators (e.g. ARNI) be more operationally efficient while retaining safety and meeting compliance standards.

The flagship product is **Marivue IQ** (previously prototyped as "KatPort IQ"), a real-time operations dashboard and decision-support tool for port control rooms. It surfaces vessel movements, berth occupancy, yard status, gate activity, and alerts in a unified interface.

### Products

| Product | Description | Source |
|---|---|---|
| **Marivue IQ** | Ops intelligence dashboard — vessel ETA/ETD, berth digital twin, yard/gate alerts, AI assistant (ARNI) | `uploads/Marivue_IQ_POC_2.html` |
| **Slide Templates** | Gamma-compatible slide layout catalogue for presentations | `uploads/gemini-code-1782574277678.md` |

---

## Sources

- **HTML Prototype:** `uploads/Marivue_IQ_POC_2.html` — 4990-line fully-styled React/HTML prototype of Marivue IQ POC v2. Contains all CSS tokens, component styles, three themes, and interactive UI patterns.
- **Slide Layout Reference:** `uploads/gemini-code-1782574277678.md` — Gamma block/layout catalogue listing every slide layout type: basic blocks, smart layouts (columns, boxes, bullets, sequences, numbers, circles, quotes, steps), smart diagrams, and charts.

---

## Content Fundamentals

**Voice & Tone:**
- Professional, technical, but accessible to port operators and shift managers
- Action-oriented; prioritize clarity over brevity
- Avoid jargon; define terminal/shipping concepts when needed
- Use imperative voice for alerts/calls-to-action ("Check vessel ETA", "Confirm gate entry")
- Use second person ("you") for guidance and educational content

**Copy patterns:**
- Acronyms uppercase and defined on first mention (TOS, ETA, ETD, etc.)
- Numbers: spelled out for counts < 10; numerals for technical values
- Timestamps in 24-hour format (ops environment standard)
- Status labels are short, uppercase pill-style ("AT_BERTH", "INBOUND", "CRITICAL")
- Error messages: specific, actionable, show required next step
- No emoji; no exclamation points except in critical alerts
- Headings title-case; body copy sentence-case

---

## Visual Foundations

**Aesthetic:**
- Clean, minimal, data-driven design
- High contrast for readability in varying lighting (ops control room context)
- Spatial hierarchy through typography scale and white space
- No decorative backgrounds; functionality first
- Emphasis on real-time, status-driven visual feedback (color, animation)

**Color Strategy:**
- **Accent:** Magenta/pink (#C2185B light, #FF3DA5 ops) — draw attention, denote active/priority states
- **Navy:** Trust, operational context, professional tone
- **Semantic colors:** Green (success/at-berth), amber (warning/at-anchor), red (critical/inbound alert)
- **Digital Twin colors:** Specialized palette for water, quay, yard, containers — mimics real port infrastructure
- **Three themes:** Light (office), Dark (evening shift), Ops (control-room immersion with high saturation)

**Typography:**
- **IBM Plex Sans:** Neutral, professional body text and UI labels
- **IBM Plex Mono:** Data, timestamps, codes, vessel references (tabular-nums for alignment)
- **IBM Plex Serif:** Editorial / future use (not prominent in current UI)
- **Scale:** 14px base; headings up to 36px; never smaller than 11px for UI labels

**Layout & Spacing:**
- 16px grid baseline (`--gap-grid`)
- 18px card padding (`--pad-card`) — reduces to 12px in compact mode
- Consistent 8px increments (4, 8, 12, 16, 20, 24, 32, 40, 48, 64px)
- Rail sidebar (240px) + flexible main content
- Sticky topbar; sticky sidebar section headers

**Visual Motifs:**
- **Cards & surfaces:** Subtle shadows, 1px borders, rounded corners (6–14px)
- **States:** Hover via background lightening; active via accent-soft background + accent-line border
- **Density options:** Normal or compact (toggle via `[data-density]` attribute)
- **Animations:** Pulse on success/active states; fade transitions; no bounces or playful easing
- **Icons:** Lucide or similar minimal icon system (monoline, consistent weight)
- **Imagery:** None in core UI; digital twin uses abstract geometric shapes (containers, berths, roads)
- **No rounded-corner accents, gradients, or emoji**

**Control Room (Ops Theme):**
- Deep navy/cyan base (#050B17) mimics dark CRT displays
- High saturation accent (#FF3DA5) cuts through dim environments
- Cyan/aqua text (#E0F2FE) reduces eye strain during long shifts
- All colors tuned for readability under reduced ambient light

---

## Iconography

**System:** Lucide Icons (monoline, consistent 2px stroke weight)
- All system icons loaded from Lucide CDN (`lucide.dev`)
- Consistent sizing: 16px (UI labels), 20px (buttons), 24px (topbar), 32px (section headers)
- No filled variants; outline only (maintains clarity in all three themes)
- No emoji; no Unicode symbol replacements
- Custom icon: Marivue logo (wordmark + glyph) in `assets/logo.svg`

**Usage patterns:**
- Navigation: alert, menu, settings, user, power
- Vessel/berth: ship, anchor, navigation, wind
- Status: check-circle, alert-circle, info, pause, play
- Data: bar-chart, line-chart, table, map, filter
- Actions: plus, edit, trash, download, refresh, settings
- Navigation breadcrumbs: chevron-right

All assets are sourced from the provided POC prototype or referenced from Lucide CDN.

---

## File Index

| Path | Purpose |
|---|---|
| `readme.md` | This file — system overview and architecture |
| `SKILL.md` | Skill card for Claude Code integration |
| `styles.css` | Root CSS entry — `@import`s all token files |
| **tokens/** | Color, typography, spacing, font custom properties |
| `tokens/colors.css` | Light / dark / ops color themes |
| `tokens/typography.css` | Type scale, font-family declarations |
| `tokens/spacing.css` | Spacing, radius, shadow tokens |
| `tokens/fonts.css` | `@font-face` rules for IBM Plex |
| **guidelines/** | Foundation specimen cards (colors, type, spacing, brand) |
| **components/** | Reusable React UI primitives |
| `components/forms/` | Button, Input components + card |
| `components/feedback/` | Badge component + card |
| **ui_kits/** | Full-screen product UI recreations |
| `ui_kits/marivue_iq/` | Operations dashboard UI kit + README |
| **templates/slides/** | Presentation slide layouts (4 types) |
| `assets/` | Logos, icons, illustrations *(ready for future use)* |

---

## Components

### Forms & Controls
- **Button** — primary, secondary, ghost, critical variants; sm/md/lg sizes; icon support
- **Input** — text, number, search with label, placeholder, error state, icon prefix

### Feedback
- **Badge** — status pills in success, warn, critical, info, muted colors

*More components to come as system grows.*

---

## UI Kits

### Marivue IQ (Dashboard)
Full operational intelligence dashboard for port terminals. Includes:
- Real-time KPI cards (vessels in port, berth occupancy, alerts)
- Active vessel list with status badges
- Navigation sidebar and topbar
- Theme support (light / dark / ops)
- Density toggle (normal / compact)

**Screens to expand:**
- Vessel details & manifest
- Berth digital twin + planner
- Yard container grid
- Gate activity log
- Settings & preferences

---

## Slide Templates

Four ready-to-use presentation layouts (1280×720, 16:9):

1. **Title Slide** — Cover with accent line, centered text
2. **Content Slide** — Heading + two-column bullet layout
3. **Two-Column Slide** — Image + text side-by-side
4. **Metric Slide** — Large statistic with context label

All templates use Marivue color tokens and typography. Customize by editing HTML/CSS directly.

---

## How to extend

1. **Add a component**: create `components/<group>/<Name>.jsx` + `<Name>.d.ts` + `<Name>.prompt.md`
2. **Add a token**: edit files in `tokens/` and the compiler auto-refreshes
3. **Add a UI kit**: create `ui_kits/<product>/index.html` + `README.md` with `@startingPoint` tag
4. **Add a slide**: create `templates/slides/<Layout>.html` with `@dsCard group="Slides"` tag
5. **Create a foundation card**: make an `.html` file in `guidelines/` with `@dsCard` tag

After any change, the compiler regenerates `_ds_bundle.js`, `_ds_manifest.json`, and `_adherence.oxlintrc.json` automatically.

---

## Caveats & Next Steps

- **Fonts**: Currently using Google Fonts CDN for IBM Plex. For production, download and self-host the font files in `assets/fonts/` to reduce external dependencies.
- **Icons**: Using Lucide CDN reference. If offline support is needed, download Lucide SVGs and create a custom icon component.
- **Components**: Only Button, Input, and Badge are implemented. Common additions: Select, Checkbox, Radio, Switch, Card, Tabs, Dialog, Toast, Tooltip.
- **Digital Twin**: The Marivue IQ UI kit mentions digital twin colors (water, quay, containers, roads) but does not yet include the 2D/3D visualization component.
- **AI Assistant (ARNI)**: Not yet represented in UI kit — ready to add chat panel, recommendations widget, etc.
- **Documentation**: Each component should have usage guidelines and common patterns. Expand `.prompt.md` files as needed.

---

**Questions for you:**

1. Should I add more UI components (Select, Checkbox, Radio, Switch, Card, Tabs, Dialog, Toast)?
2. Do you want Design Components (`.dc.html`) instead of static HTML for the slide templates so they're more interactive in preview?
3. Should I create a digital twin / map visualization component for the Marivue IQ kit?
4. Do you want to add ARNI (the AI assistant) as a visible chat/recommendations widget in the dashboard?
5. Should the three themes (light, dark, ops) be togglable via a Tweaks panel in the UI kit for testing?

*Let me know what to prioritize next!*
