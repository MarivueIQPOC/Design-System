# Slide Templates — Slide Master System

Interactive, reusable slide templates for product presentations, proposals, GTM playbooks, and investor decks.

## 🎯 Available Templates

All templates are **Design Components** (`.dc.html`) — fully interactive with live Tweaks editing. Each template lives in its own folder for seamless design-system integration.

| Template | Best For | Location |
|---|---|---|
| **Title Slide** | Cover pages, section dividers | `templates/title-slide/` |
| **Content Slide** | Key capabilities, features, benefits | `templates/content-slide/` |
| **Two-Column Slide** | Product positioning, feature spotlights | `templates/two-column/` |
| **Metric Slide** | ROI, efficiency gains, results showcase | `templates/metric/` |
| **Three-Column Slide** | Value props, pillars, solution overview | `templates/three-column/` |
| **Steps Slide** | Implementation phases, GTM roadmap, workflows | `templates/steps/` |
| **Quote Slide** | Testimonials, customer success statements | `templates/quote/` |
| **Comparison Slide** | Before/after, manual vs automated, competitive positioning | `templates/comparison/` |

## 🚀 How to Use

### Quick Edit (Live Preview)
1. Open any template from the **Templates** menu in the Design System tab
2. Click **Tweaks** (toolbar) to edit live:
   - Headings, bullets, metrics, descriptions
   - All text fields editable in-place
3. Preview updates instantly with Marivue colors and typography

### Copy to Your Deck
1. Open template in preview
2. Copy the rendered HTML
3. Paste into your slide deck builder (Figma, Deck, PPTX, etc.)
4. Or export as HTML and customize further

### Extend a Template
Each template uses:
- **Marivue design tokens** (colors, typography, spacing)
- **Responsive 1280×720 (16:9)** layout
- **Component library** (Button, Badge, etc.) ready to integrate

Edit the `.dc.html` directly to customize beyond Tweaks.

## 📐 Specifications

- **Dimensions**: 1280×720px (16:9 widescreen)
- **Colors**: Full Marivue palette (light/dark/ops themes via CSS var)
- **Typography**: IBM Plex Sans, 14px base, full scale
- **Spacing**: 4px baseline grid, consistent with Marivue design system

---

*Built on Marivue Design System. Last updated: June 2026*
