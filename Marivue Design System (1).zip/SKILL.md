---
name: marivue-design
description: Design system for Marivue — port operations intelligence platform. Contains color tokens, typography, spacing system, reusable UI components (Button, Input, Badge), Marivue IQ dashboard UI kit, and presentation slide templates. Use for building branded interfaces for port control rooms and operations dashboards.
user-invocable: true
---

# Marivue Design System

Use this skill to design and build interfaces for **Marivue** — the intelligence layer connecting to Terminal Operating Systems (TOS) to help port operators be more efficient while retaining safety and compliance.

## What's included

- **Design Tokens** — color system (light, dark, ops themes), typography (IBM Plex), spacing scale, radius, shadows
- **Components** — Button, Input, Badge (all React + TypeScript)
- **UI Kit** — Marivue IQ dashboard: navbar, sidebar, vessel tracking, berth status, alerts
- **Slide Templates** — Title, Content, Two-Column, Metric slides (1280×720, 16:9)
- **Foundation Guidelines** — visual system, content voice, digital twin colors

## How to use

1. **Read `readme.md`** at the project root for full context on company, products, and design system structure.
2. **For visual assets**, explore the `guidelines/` folder — foundation cards show colors, type scale, spacing, and brand patterns.
3. **For components**, check `components/forms/` and `components/feedback/` — each has `.jsx`, `.d.ts`, and `.prompt.md` with usage examples.
4. **For the Marivue IQ UI kit**, see `ui_kits/marivue_iq/` — contains the base dashboard screen and README with all available screens.
5. **For slides**, explore `templates/slides/` — four layout templates ready to customize.

## To create with this system

- **Building a dashboard or admin interface** → start with the Marivue IQ UI kit as a template; reuse Button, Input, Badge components
- **Creating a presentation** → pick a slide template and customize title, content, colors
- **Designing a custom component** → follow the pattern in `components/` (`.jsx` + `.d.ts` + `.prompt.md`)
- **Tweaking colors or spacing** → edit the token files in `tokens/` and the system auto-recompiles

## Key design principles

- **Three themes**: light (office), dark (evening), ops (control-room immersion with high-saturation accent)
- **Data-driven**: typography and color choices optimized for real-time operations dashboards
- **Professional + minimal**: no decorative flourishes; clarity and hierarchy above all
- **Accessible**: high contrast, consistent icon system (Lucide), readable at multiple scales

---

For production questions or to extend the system, see the root `readme.md`.
