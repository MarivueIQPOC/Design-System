# Marivue IQ UI Kit

Operations intelligence dashboard for port terminals. Real-time vessel tracking, berth management, yard status, and alert handling.

## Screens

- **Dashboard** — real-time port KPIs, active vessel list, alert summary
- **Vessel Details** — single vessel ETA, status, cargo manifest preview
- **Berth Planner** — digital twin visualization, berth availability
- **Yard Status** — container position grid, vehicle movements
- **Gate Activity** — truck entry/exit log, queue management
- **Settings** — theme toggle, density, user preferences

## Key Features

- Three themes: light, dark, ops (control-room)
- Responsive sidebar navigation
- Real-time status badges (at berth, inbound, waiting, loading, critical)
- Compact and normal density modes
- Alert hierarchy (info, warn, critical)
- Digital twin mini-maps (not included in base kit — see design system guidelines)

---

*Last updated: June 2026*
